This program has only been tested on windows 10 and comes as is.
It is very buggy and liable to crash.
I bare no responsibility for any damages caused by the running of this program.

So its not *quite* a completed product yet, but if you run 'Main.exe' it *should* run.
If not then it'll probably be too painful to get things set up for you to play it.
That would make for a sad Demi =( but here's hoping the gods of coding are smiling on us today =)

Main issues with the program at the moment are:
 - Word weights (how likely an option is given what you've said)
 - Internal communications within the program itself (multiprocessing is weird)

Beyond that its a fully functional prototype! =)

If you could give me the log_file.txt file that is generated at the end of the game, (crash or no crash), then I can look into possibly improving things (and actually complete the coursework!)

That's all folks, hope you enjoy the game!
